
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

try {
  const root = ReactDOM.createRoot(rootElement);
  root.render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
} catch (error) {
  console.error("Catastrophic mount failure:", error);
  rootElement.innerHTML = `<div style="color: red; padding: 20px; font-family: monospace;">
    <h1>System Initialization Error</h1>
    <p>${error instanceof Error ? error.message : String(error)}</p>
  </div>`;
}
